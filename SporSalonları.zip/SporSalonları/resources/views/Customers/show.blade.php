@extends('layouts.app')

@section('title', 'Müşteri Detayları')

@section('content')
    <h2>Müşteri Detayları</h2>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">{{ $customer->first_name }} {{ $customer->last_name }}</h5>
            <p class="card-text"><strong>Telefon:</strong> {{ $customer->phone }}</p>
            <p class="card-text"><strong>Email:</strong> {{ $customer->email }}</p>
            <a href="{{ route('customers.index') }}" class="btn btn-secondary">Geri</a>
        </div>
    </div>
@endsection
