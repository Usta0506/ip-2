@extends('layouts.app')

@section('title', 'Müşteri Düzenle')

@section('content')
    <h2>Müşteri Düzenle</h2>
    <form action="{{ route('customers.update', $customer->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label for="first_name" class="form-label">Ad</label>
            <input type="text" name="first_name" id="first_name" value="{{ $customer->first_name }}" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="last_name" class="form-label">Soyad</label>
            <input type="text" name="last_name" id="last_name" value="{{ $customer->last_name }}" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">Telefon</label>
            <input type="text" name="phone" id="phone" value="{{ $customer->phone }}" class="form-control">
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" id="email" value="{{ $customer->email }}" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Güncelle</button>
    </form>
@endsection
