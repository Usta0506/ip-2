<!DOCTYPE html>
<html>
<head>
    <title>Customer Details</title>
</head>
<body>
<h1>{{ $customer->FirstName }} {{ $customer->LastName }}</h1>
<p>Date of Birth: {{ $customer->DateOfBirth }}</p>
<p>Phone: {{ $customer->Phone }}</p>
<p>Email: {{ $customer->Email }}</p>
<p>Address: {{ $customer->Address }}</p>
</body>
</html>

