@extends('layouts.app')

@section('title', 'Ana Sayfa')

@section('content')
    <div class="text-center">
        <h1>Hoş Geldiniz</h1>
        <p>Spor salonunuzu kolayca yönetin!</p>
        <a href="{{ route('customers.index') }}" class="btn btn-primary">Müşterileri Görüntüle</a>
    </div>
@endsection
