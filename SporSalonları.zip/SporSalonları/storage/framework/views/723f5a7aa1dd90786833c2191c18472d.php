<?php $__env->startSection('title', 'Ana Sayfa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1>Hoş Geldiniz</h1>
        <p>Spor salonunuzu kolayca yönetin!</p>
        <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-primary">Müşterileri Görüntüle</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eunse\Desktop\SporSalonları\SporSalonları\resources\views/home.blade.php ENDPATH**/ ?>