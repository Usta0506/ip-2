<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('trainers', function (Blueprint $table) {
            $table->id('TrainerID');
            $table->string('FirstName', 50);
            $table->string('LastName', 50);
            $table->string('Phone', 15)->nullable();
            $table->string('Email', 100)->unique();
            $table->timestamps();
        });
    }

};
