<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('participations', function (Blueprint $table) {
            $table->id('ParticipationID');
            $table->unsignedBigInteger('CustomerID');
            $table->dateTime('EntryTime');
            $table->dateTime('ExitTTime')->nullable();
            $table->foreign('CustomerID')->references('CustomerID')->on('customers');
            $table->timestamps();
        });
    }

};
