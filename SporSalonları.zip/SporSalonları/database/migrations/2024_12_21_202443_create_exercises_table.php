<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('exercises', function (Blueprint $table) {
            $table->id('ExerciseID');
            $table->string('Name', 50);
            $table->string('MuscleGroup', 50);
            $table->timestamps();
        });
    }

};
