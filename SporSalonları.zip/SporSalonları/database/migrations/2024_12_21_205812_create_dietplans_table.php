<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('diet_plans', function (Blueprint $table) {
            $table->id('DietPlanID');
            $table->unsignedBigInteger('CustomerID');
            $table->unsignedBigInteger('TrainerID');
            $table->text('PlanDescription')->nullable();
            $table->date('StartDate');
            $table->date('EndDate');
            $table->foreign('CustomerID')->references('CustomerID')->on('customers');
            $table->foreign('TrainerID')->references('TrainerID')->on('trainers');
            $table->timestamps();
        });
    }

};
