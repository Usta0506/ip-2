<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up()
    {
        Schema::create('memberships', function (Blueprint $table) {
            $table->id('MembershipID');
            $table->unsignedBigInteger('CustomerID');
            $table->date('StartDate');
            $table->date('EndDate');
            $table->unsignedBigInteger('MembershipTypeID');
            $table->foreign('CustomerID')->references('CustomerID')->on('customers');
            $table->foreign('MembershipTypeID')->references('MembershipTypeID')->on('membership_type');
            $table->timestamps();
        });
    }
};
