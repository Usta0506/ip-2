<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id('PaymentID');
            $table->unsignedBigInteger('CustomerID');
            $table->decimal('Amount', 10, 2);
            $table->date('PaymentDate');
            $table->string('PaymentType', 50);
            $table->foreign('CustomerID')->references('CustomerID')->on('customers');
            $table->timestamps();
        });
    }

};
