<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('workout_plans', function (Blueprint $table) {
            $table->id('WorkoutPlanID');
            $table->unsignedBigInteger('ProgramID');
            $table->unsignedBigInteger('CustomerID');
            $table->date('StartDate');
            $table->date('EndDate');
            $table->foreign('ProgramID')->references('ProgramID')->on('programs');
            $table->foreign('CustomerID')->references('CustomerID')->on('customers');
            $table->timestamps();
        });
    }

};
