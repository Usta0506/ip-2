<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('locker_rooms', function (Blueprint $table) {
            $table->id('LockerID');
            $table->string('LockerNumber', 10)->unique();
            $table->string('Status', 20)->default('Available');
            $table->unsignedBigInteger('AssignedCustomerID')->nullable();
            $table->foreign('AssignedCustomerID')->references('CustomerID')->on('customers');
            $table->timestamps();
        });
    }

};
