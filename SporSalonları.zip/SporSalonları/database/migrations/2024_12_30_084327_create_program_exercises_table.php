<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('program_exercises', function (Blueprint $table) {
            $table->id('ProgramExerciseID');
            $table->unsignedBigInteger('WorkoutPlanID');
            $table->unsignedBigInteger('ExerciseID');
            $table->integer('SetCount');
            $table->integer('RepetitionCount');
            $table->foreign('WorkoutPlanID')->references('WorkoutPlanID')->on('workout_plans');
            $table->foreign('ExerciseID')->references('ExerciseID')->on('exercises');
            $table->timestamps();
        });
    }

};
