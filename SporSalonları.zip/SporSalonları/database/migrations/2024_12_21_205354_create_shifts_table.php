<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('shifts', function (Blueprint $table) {
            $table->id('ShiftID');
            $table->unsignedBigInteger('StaffID');
            $table->time('StartTime');
            $table->time('EndTime');
            $table->date('Date');
            $table->foreign('StaffID')->references('StaffID')->on('staff');
            $table->timestamps();
        });
    }

};
