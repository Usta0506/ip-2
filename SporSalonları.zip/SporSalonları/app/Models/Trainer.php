<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Trainer extends Model
{
    use HasFactory;

    protected $primaryKey = 'TrainerID';

    protected $fillable = [
        'FirstName',
        'LastName',
        'Phone',
        'Email',
    ];

    public function ietPlans()
    {
        return $this->hasMany(DietPlan::class, 'TrainerID');
    }

    public function clasess()
    {
        return $this->hasMany(ClassModel::class, 'TrainerID');
    }
}
