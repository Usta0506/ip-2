<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClassModel extends Model
{
    use HasFactory;

    protected $primaryKey = 'ClassID';

    protected $fillable = [
        'Name',
        'GymID',
        'StartTime',
        'EndTime',
        'TrainerID',
    ];

    public function trainer()
    {
        return $this->belongsTo(Trainer::class, 'TrainerID');
    }

    public function customers()
    {
        return $this->belongsToMany(Customer::class, 'class_members', 'ClassID', 'CustomerID');
    }
}
