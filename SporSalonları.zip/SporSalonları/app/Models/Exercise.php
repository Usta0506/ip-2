<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Exercise extends Model
{
    use HasFactory;

    protected $primaryKey = 'ExerciseID';

    protected $fillable = [
        'Name',
        'MuscleGroup',
    ];

    public function programExercises()
    {
        return $this->hasMany(ProgramExercise::class, 'ExerciseID');
    }
}
