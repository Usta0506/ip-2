<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Memberships extends Model
{
    use HasFactory;

    protected $primaryKey = 'MembershipID';

    protected $fillable = [
        'CustomerID',
        'StartDate',
        'EndDate',
        'MembershipTypeID',
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'CustomerID');
    }

    public function membershipType()
    {
        return $this->belongsTo(MembershipType::class, 'MembershipTypeID');
    }
}
