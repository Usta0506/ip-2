<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Equipment extends Model
{
    use HasFactory;

    protected $primaryKey = 'EquipmentID';

    protected $fillable = [
        'Name',
        'GymID',
        'Condition',
    ];

    public function gym()
    {
        return $this->belongsTo(Gym::class, 'GymID');
    }
}

