<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClassMember extends Model
{
    use HasFactory;

    protected $primaryKey = 'ClassMemberID';

    protected $fillable = [
        'ClassID',
        'CustomerID',
    ];

    public function class()
    {
        return $this->belongsTo(ClassModel::class, 'ClassID');
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'CustomerID');
    }
}

