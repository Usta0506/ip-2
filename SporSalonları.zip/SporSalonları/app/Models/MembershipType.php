<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MembershipType extends Model
{
    use HasFactory;

    protected $primaryKey = 'MembershipTypeID';

    protected $fillable = [
        'Name',
        'Description',
    ];

    public function memberships()
    {
        return $this->hasMany(Membership::class, 'MembershipTypeID');
    }
}

