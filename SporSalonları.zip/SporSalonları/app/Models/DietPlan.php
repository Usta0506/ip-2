<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DietPlan extends Model
{
    use HasFactory;

    protected $primaryKey = 'DietPlanID';

    protected $fillable = [
        'CustomerID',
        'TrainerID',
        'PlanDescription',
        'StartDate',
        'EndDate',
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'CustomerID');
    }

    public function trainer()
    {
        return $this->belongsTo(Trainer::class, 'TrainerID');
    }
}
