<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    protected $primaryKey = 'CustomerID';

    protected $fillable = [
        'FirstName',
        'LastName',
        'Phone',
        'Email',
    ];

    public function memberships()
    {
        return $this->hasMany(Membership::class, 'CustomerID');
    }

    public function workoutPlans()
    {
        return $this->hasMany(WorkoutPlan::class, 'CustomerID');
    }

    public function attendance()
    {
        return $this->hasMany(Attendance::class, 'CustomerID');
    }

    public function dietPlans()
    {
        return $this->hasMany(DietPlan::class, 'CustomerID');
    }

    public function classes()
    {
        return $this->belongsToMany(ClassModel::class, 'class_members', 'CustomerID', 'ClassID');
    }

    public function locker()
    {
        return $this->hasOne(LockerRoom::class, 'AssignedCustomerID');
    }

    public function payments()
    {
        return $this->hasMany(Payment::class, 'CustomerID');
    }
}
