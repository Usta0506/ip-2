<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use HasFactory;

    protected $primaryKey = 'StaffID';

    protected $fillable = [
        'FirstName',
        'LastName',
        'Position',
        'Phone',
        'Email',
    ];

    public function shifts()
    {
        return $this->hasMany(Shift::class, 'StaffID');
    }
}
