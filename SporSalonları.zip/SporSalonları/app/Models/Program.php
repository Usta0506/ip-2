<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Program extends Model
{
    use HasFactory;

    protected $primaryKey = 'ProgramID';

    protected $fillable = [
        'Name',
        'Description',
    ];

    public function workoutPlans()
    {
        return $this->hasMany(WorkoutPlan::class, 'ProgramID');
    }
}

