<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;

    protected $primaryKey = 'PaymentID';

    protected $fillable = [
        'CustomerID',
        'Amount',
        'PaymentDate',
        'PaymentType',
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'CustomerID');
    }

    public function invoice()
    {
        return $this->hasOne(Invoice::class, 'PaymentID');
    }
}
