<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProgramExercise extends Model
{
    use HasFactory;

    protected $primaryKey = 'ProgramExerciseID';

    protected $fillable = [
        'WorkoutPlanID',
        'ExerciseID',
        'SetCount',
        'RepetitionCount',
    ];

    public function workoutPlan()
    {
        return $this->belongsTo(WorkoutPlan::class, 'WorkoutPlanID');
    }

    public function exercise()
    {
        return $this->belongsTo(Exercise::class, 'ExerciseID');
    }
}

