<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gym extends Model
{
    use HasFactory;

    protected $primaryKey = 'GymID';

    protected $fillable = [
        'Name',
        'Address',
        'Phone',
    ];

    public function equipment()
    {
        return $this->hasMany(Equipment::class, 'GymID');
    }

    public function classes()
    {
        return $this->hasMany(ClassModel::class, 'GymID');
    }
}

