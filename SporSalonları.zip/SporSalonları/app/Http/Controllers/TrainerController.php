<?php


namespace App\Http\Controllers;

use App\Models\Trainer;
use Illuminate\Http\Request;

class TrainerController extends Controller
{
    public function index()
    {
        $trainers = Trainer::all();
        return response()->json($trainers);
    }

    public function show($id)
    {
        $trainer = Trainer::find($id);
        if (!$trainer) {
            return response()->json(['error' => 'Trainer not found'], 404);
        }
        return response()->json($trainer);
    }

    public function store(Request $request)
    {
        $request->validate([
            'FirstName' => 'required|string|max:50',
            'LastName' => 'required|string|max:50',
            'Phone' => 'required|string|max:15',
            'Email' => 'required|email|max:100',
        ]);

        $trainer = Trainer::create($request->all());
        return response()->json(['message' => 'Trainer created successfully', 'trainer' => $trainer], 201);
    }

    public function update(Request $request, $id)
    {
        $trainer = Trainer::find($id);
        if (!$trainer) {
            return response()->json(['error' => 'Trainer not found'], 404);
        }

        $trainer->update($request->all());
        return response()->json(['message' => 'Trainer updated successfully', 'trainer' => $trainer]);
    }

    public function destroy($id)
    {
        $trainer = Trainer::find($id);
        if (!$trainer) {
            return response()->json(['error' => 'Trainer not found'], 404);
        }

        $trainer->delete();
        return response()->json(['message' => 'Trainer deleted successfully']);
    }
}

