<?php


namespace App\Http\Controllers;

use App\Models\Shift;
use Illuminate\Http\Request;

class ShiftController extends Controller
{
    public function index()
    {
        $shifts = Shift::all();
        return response()->json($shifts);
    }

    public function show($id)
    {
        $shift = Shift::find($id);
        if (!$shift) {
            return response()->json(['error' => 'Shift not found'], 404);
        }
        return response()->json($shift);
    }

    public function store(Request $request)
    {
        $request->validate([
            'StaffID' => 'required|exists:staff,StaffID',
            'StartTime' => 'required|date_format:H:i',
            'EndTime' => 'required|date_format:H:i',
            'Date' => 'required|date',
        ]);

        $shift = Shift::create($request->all());
        return response()->json(['message' => 'Shift created successfully', 'shift' => $shift], 201);
    }

    public function update(Request $request, $id)
    {
        $shift = Shift::find($id);
        if (!$shift) {
            return response()->json(['error' => 'Shift not found'], 404);
        }

        $shift->update($request->all());
        return response()->json(['message' => 'Shift updated successfully', 'shift' => $shift]);
    }

    public function destroy($id)
    {
        $shift = Shift::find($id);
        if (!$shift) {
            return response()->json(['error' => 'Shift not found'], 404);
        }

        $shift->delete();
        return response()->json(['message' => 'Shift deleted successfully']);
    }
}
