<?php


namespace App\Http\Controllers;

use App\Models\Membership;
use App\Models\Memberships;
use Illuminate\Http\Request;

class MembershipController extends Controller
{
    public function index()
    {
        $memberships = Membership::all();
        return response()->json($memberships);
    }

    public function show($id)
    {
        $membership = Membership::find($id);
        if (!$membership) {
            return response()->json(['error' => 'Membership not found'], 404);
        }
        return response()->json($membership);
    }

    public function store(Request $request)
    {
        $request->validate([
            'CustomerID' => 'required|exists:customers,CustomerID',
            'StartDate' => 'required|date',
            'EndDate' => 'required|date',
            'MembershipTypeID' => 'required|exists:membership_types,MembershipTypeID',
        ]);

        $membership = Memberships::create($request->all());
        return response()->json(['message' => 'Membership created successfully', 'membership' => $membership], 201);
    }

    public function update(Request $request, $id)
    {
        $membership = Memberships::find($id);
        if (!$membership) {
            return response()->json(['error' => 'Membership not found'], 404);
        }

        $membership->update($request->all());
        return response()->json(['message' => 'Membership updated successfully', 'membership' => $membership]);
    }

    public function destroy($id)
    {
        $membership = Memberships::find($id);
        if (!$membership) {
            return response()->json(['error' => 'Membership not found'], 404);
        }

        $membership->delete();
        return response()->json(['message' => 'Membership deleted successfully']);
    }
}
