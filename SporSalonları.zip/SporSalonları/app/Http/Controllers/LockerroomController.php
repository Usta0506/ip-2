<?php


namespace App\Http\Controllers;

use App\Models\LockerRoom;
use Illuminate\Http\Request;

class LockerRoomController extends Controller
{
    public function index()
    {
        $lockerRooms = LockerRoom::all();
        return response()->json($lockerRooms);
    }

    public function show($id)
    {
        $lockerRoom = LockerRoom::find($id);
        if (!$lockerRoom) {
            return response()->json(['error' => 'Locker Room not found'], 404);
        }
        return response()->json($lockerRoom);
    }

    public function store(Request $request)
    {
        $request->validate([
            'LockerNumber' => 'required|string|max:10',
            'Status' => 'required|string|max:20',
            'AssignedCustomerID' => 'nullable|exists:customers,CustomerID',
        ]);

        $lockerRoom = LockerRoom::create($request->all());
        return response()->json(['message' => 'Locker Room created successfully', 'lockerRoom' => $lockerRoom], 201);
    }

    public function update(Request $request, $id)
    {
        $lockerRoom = LockerRoom::find($id);
        if (!$lockerRoom) {
            return response()->json(['error' => 'Locker Room not found'], 404);
        }

        $lockerRoom->update($request->all());
        return response()->json(['message' => 'Locker Room updated successfully', 'lockerRoom' => $lockerRoom]);
    }

    public function destroy($id)
    {
        $lockerRoom = LockerRoom::find($id);
        if (!$lockerRoom) {
            return response()->json(['error' => 'Locker Room not found'], 404);
        }

        $lockerRoom->delete();
        return response()->json(['message' => 'Locker Room deleted successfully']);
    }
}
