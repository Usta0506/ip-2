<?php


namespace App\Http\Controllers;

use App\Models\Gym;
use Illuminate\Http\Request;

class GymController extends Controller
{
    public function index()
    {
        $gyms = Gym::all();
        return response()->json($gyms);
    }

    public function show($id)
    {
        $gym = Gym::find($id);
        if (!$gym) {
            return response()->json(['error' => 'Gym not found'], 404);
        }
        return response()->json($gym);
    }

    public function store(Request $request)
    {
        $request->validate([
            'Name' => 'required|string|max:50',
            'Address' => 'required|string',
            'Phone' => 'required|string|max:15',
        ]);

        $gym = Gym::create($request->all());
        return response()->json(['message' => 'Gym created successfully', 'gym' => $gym], 201);
    }

    public function update(Request $request, $id)
    {
        $gym = Gym::find($id);
        if (!$gym) {
            return response()->json(['error' => 'Gym not found'], 404);
        }

        $gym->update($request->all());
        return response()->json(['message' => 'Gym updated successfully', 'gym' => $gym]);
    }

    public function destroy($id)
    {
        $gym = Gym::find($id);
        if (!$gym) {
            return response()->json(['error' => 'Gym not found'], 404);
        }

        $gym->delete();
        return response()->json(['message' => 'Gym deleted successfully']);
    }
}
