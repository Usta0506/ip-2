<?php


namespace App\Http\Controllers;

use App\Models\MembershipType;
use Illuminate\Http\Request;

class MembershiptypeController extends Controller
{
    public function index()
    {
        $membershipTypes = MembershipType::all();
        return response()->json($membershipTypes);
    }

    public function show($id)
    {
        $membershipType = MembershipType::find($id);
        if (!$membershipType) {
            return response()->json(['error' => 'Membership Type not found'], 404);
        }
        return response()->json($membershipType);
    }

    public function store(Request $request)
    {
        $request->validate([
            'Name' => 'required|string|max:50',
            'Description' => 'required|string',
        ]);

        $membershipType = MembershipType::create($request->all());
        return response()->json(['message' => 'Membership Type created successfully', 'membershipType' => $membershipType], 201);
    }

    public function update(Request $request, $id)
    {
        $membershipType = MembershipType::find($id);
        if (!$membershipType) {
            return response()->json(['error' => 'Membership Type not found'], 404);
        }

        $membershipType->update($request->all());
        return response()->json(['message' => 'Membership Type updated successfully', 'membershipType' => $membershipType]);
    }

    public function destroy($id)
    {
        $membershipType = MembershipType::find($id);
        if (!$membershipType) {
            return response()->json(['error' => 'Membership Type not found'], 404);
        }

        $membershipType->delete();
        return response()->json(['message' => 'Membership Type deleted successfully']);
    }
}

