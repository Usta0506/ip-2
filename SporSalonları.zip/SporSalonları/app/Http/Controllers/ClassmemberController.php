<?php


namespace App\Http\Controllers;

use App\Models\ClassMember;
use Illuminate\Http\Request;

class ClassMemberController extends Controller
{
    public function index()
    {
        $classMembers = ClassMember::all();
        return response()->json($classMembers);
    }

    public function show($id)
    {
        $classMember = ClassMember::find($id);
        if (!$classMember) {
            return response()->json(['error' => 'Class Member not found'], 404);
        }
        return response()->json($classMember);
    }

    public function store(Request $request)
    {
        $request->validate([
            'ClassID' => 'required|exists:classes,ClassID',
            'CustomerID' => 'required|exists:customers,CustomerID',
        ]);

        $classMember = ClassMember::create($request->all());
        return response()->json(['message' => 'Class Member created successfully', 'classMember' => $classMember], 201);
    }

    public function update(Request $request, $id)
    {
        $classMember = ClassMember::find($id);
        if (!$classMember) {
            return response()->json(['error' => 'Class Member not found'], 404);
        }

        $classMember->update($request->all());
        return response()->json(['message' => 'Class Member updated successfully', 'classMember' => $classMember]);
    }

    public function destroy($id)
    {
        $classMember = ClassMember::find($id);
        if (!$classMember) {
            return response()->json(['error' => 'Class Member not found'], 404);
        }

        $classMember->delete();
        return response()->json(['message' => 'Class Member deleted successfully']);
    }
}

