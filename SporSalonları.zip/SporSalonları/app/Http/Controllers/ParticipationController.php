<?php

// app/Http/Controllers/ParticipationController.php
namespace App\Http\Controllers;

use App\Models\Participation;
use Illuminate\Http\Request;

class ParticipationController extends Controller
{
    public function index()
    {
        $participations = Participation::all();
        return response()->json($participations);
    }

    public function show($id)
    {
        $participation = Participation::find($id);
        if (!$participation) {
            return response()->json(['error' => 'Participation not found'], 404);
        }
        return response()->json($participation);
    }

    public function store(Request $request)
    {
        $request->validate([
            'CustomerID' => 'required|exists:customers,CustomerID',
            'CheckInTime' => 'required|date',
            'CheckOutTime' => 'nullable|date',
        ]);

        $participation = Participation::create($request->all());
        return response()->json(['message' => 'Participation recorded successfully', 'participation' => $participation], 201);
    }

    public function update(Request $request, $id)
    {
        $participation = Participation::find($id);
        if (!$participation) {
            return response()->json(['error' => 'Participation not found'], 404);
        }

        $participation->update($request->all());
        return response()->json(['message' => 'Participation updated successfully', 'participation' => $participation]);
    }

    public function destroy($id)
    {
        $participation = Participation::find($id);
        if (!$participation) {
            return response()->json(['error' => 'Participation not found'], 404);
        }

        $participation->delete();
        return response()->json(['message' => 'Participation deleted successfully']);
    }
}
