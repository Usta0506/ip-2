<?php


namespace App\Http\Controllers;

use App\Models\Equipment;
use Illuminate\Http\Request;

class EquipmentController extends Controller
{
    public function index()
    {
        $equipment = Equipment::all();
        return response()->json($equipment);
    }

    public function show($id)
    {
        $equipment = Equipment::find($id);
        if (!$equipment) {
            return response()->json(['error' => 'Equipment not found'], 404);
        }
        return response()->json($equipment);
    }

    public function store(Request $request)
    {
        $request->validate([
            'Name' => 'required|string|max:50',
            'GymID' => 'required|exists:gyms,GymID',
            'Condition' => 'required|string|max:50',
        ]);

        $equipment = Equipment::create($request->all());
        return response()->json(['message' => 'Equipment created successfully', 'equipment' => $equipment], 201);
    }

    public function update(Request $request, $id)
    {
        $equipment = Equipment::find($id);
        if (!$equipment) {
            return response()->json(['error' => 'Equipment not found'], 404);
        }

        $equipment->update($request->all());
        return response()->json(['message' => 'Equipment updated successfully', 'equipment' => $equipment]);
    }

    public function destroy($id)
    {
        $equipment = Equipment::find($id);
        if (!$equipment) {
            return response()->json(['error' => 'Equipment not found'], 404);
        }

        $equipment->delete();
        return response()->json(['message' => 'Equipment deleted successfully']);
    }
}
