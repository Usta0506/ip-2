<?php


namespace App\Http\Controllers;

use App\Models\Exercise;
use Illuminate\Http\Request;

class ExerciseController extends Controller
{
    public function index()
    {
        $exercises = Exercise::all();
        return response()->json($exercises);
    }

    public function show($id)
    {
        $exercise = Exercise::find($id);
        if (!$exercise) {
            return response()->json(['error' => 'Exercise not found'], 404);
        }
        return response()->json($exercise);
    }

    public function store(Request $request)
    {
        $request->validate([
            'Name' => 'required|string|max:50',
            'MuscleGroup' => 'required|string|max:50',
        ]);

        $exercise = Exercise::create($request->all());
        return response()->json(['message' => 'Exercise created successfully', 'exercise' => $exercise], 201);
    }

    public function update(Request $request, $id)
    {
        $exercise = Exercise::find($id);
        if (!$exercise) {
            return response()->json(['error' => 'Exercise not found'], 404);
        }

        $exercise->update($request->all());
        return response()->json(['message' => 'Exercise updated successfully', 'exercise' => $exercise]);
    }

    public function destroy($id)
    {
        $exercise = Exercise::find($id);
        if (!$exercise) {
            return response()->json(['error' => 'Exercise not found'], 404);
        }

        $exercise->delete();
        return response()->json(['message' => 'Exercise deleted successfully']);
    }
}
