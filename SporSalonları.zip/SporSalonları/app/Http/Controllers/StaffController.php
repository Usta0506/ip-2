<?php


namespace App\Http\Controllers;

use App\Models\Staff;
use Illuminate\Http\Request;

class StaffController extends Controller
{
    public function index()
    {
        $staffMembers = Staff::all();
        return response()->json($staffMembers);
    }

    public function show($id)
    {
        $staff = Staff::find($id);
        if (!$staff) {
            return response()->json(['error' => 'Staff not found'], 404);
        }
        return response()->json($staff);
    }

    public function store(Request $request)
    {
        $request->validate([
            'FirstName' => 'required|string|max:50',
            'LastName' => 'required|string|max:50',
            'Position' => 'required|string|max:50',
            'Phone' => 'required|string|max:15',
            'Email' => 'required|email|max:100',
        ]);

        $staff = Staff::create($request->all());
        return response()->json(['message' => 'Staff member created successfully', 'staff' => $staff], 201);
    }

    public function update(Request $request, $id)
    {
        $staff = Staff::find($id);
        if (!$staff) {
            return response()->json(['error' => 'Staff not found'], 404);
        }

        $staff->update($request->all());
        return response()->json(['message' => 'Staff updated successfully', 'staff' => $staff]);
    }

    public function destroy($id)
    {
        $staff = Staff::find($id);
        if (!$staff) {
            return response()->json(['error' => 'Staff not found'], 404);
        }

        $staff->delete();
        return response()->json(['message' => 'Staff deleted successfully']);
    }
}
