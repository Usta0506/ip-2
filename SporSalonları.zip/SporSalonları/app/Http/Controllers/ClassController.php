<?php

namespace App\Http\Controllers;

use App\Models\ClassModel;
use App\Models\Trainer;
use App\Models\Gym;
use Illuminate\Http\Request;

class ClassController extends Controller
{

    public function index()
    {

        $classes = ClassModel::with(['trainer', 'gym'])->get();
        return response()->json($classes);
    }


    public function show($id)
    {

        $class = ClassModel::with(['trainer', 'gym'])->find($id);

        if (!$class) {
            return response()->json(['error' => 'Class not found'], 404);
        }

        return response()->json($class);
    }


    public function store(Request $request)
    {

        $request->validate([
            'Name' => 'required|string|max:50',
            'GymID' => 'required|exists:gyms,GymID',
            'StartTime' => 'required|date_format:H:i',
            'EndTime' => 'required|date_format:H:i|after:StartTime',
            'TrainerID' => 'required|exists:trainers,TrainerID',
        ]);

        // Yeni sınıf kaydını oluşturuyoruz
        $class = ClassModel::create([
            'Name' => $request->Name,
            'GymID' => $request->GymID,
            'StartTime' => $request->StartTime,
            'EndTime' => $request->EndTime,
            'TrainerID' => $request->TrainerID,
        ]);

        return response()->json([
            'message' => 'Class created successfully',
            'class' => $class
        ], 201);
    }


    public function update(Request $request, $id)
    {

        $class = ClassModel::find($id);

        if (!$class) {
            return response()->json(['error' => 'Class not found'], 404);
        }


        $request->validate([
            'Name' => 'sometimes|required|string|max:50',
            'GymID' => 'sometimes|required|exists:gyms,GymID',
            'StartTime' => 'sometimes|required|date_format:H:i',
            'EndTime' => 'sometimes|required|date_format:H:i|after:StartTime',
            'TrainerID' => 'sometimes|required|exists:trainers,TrainerID',
        ]);


        $class->update($request->all());

        return response()->json([
            'message' => 'Class updated successfully',
            'class' => $class
        ]);
    }


    public function destroy($id)
    {

        $class = ClassModel::find($id);

        if (!$class) {
            return response()->json(['error' => 'Class not found'], 404);
        }

        $class->delete();

        return response()->json(['message' => 'Class deleted successfully']);
    }
}
