<?php


namespace App\Http\Controllers;

use App\Models\Supplement;
use Illuminate\Http\Request;

class SupplementController extends Controller
{
    public function index()
    {
        $supplements = Supplement::all();
        return response()->json($supplements);
    }

    public function show($id)
    {
        $supplement = Supplement::find($id);
        if (!$supplement) {
            return response()->json(['error' => 'Supplement not found'], 404);
        }
        return response()->json($supplement);
    }

    public function store(Request $request)
    {
        $request->validate([
            'Name' => 'required|string|max:50',
            'Description' => 'required|string',
            'Price' => 'required|numeric',
            'StockQuantity' => 'required|integer',
        ]);

        $supplement = Supplement::create($request->all());
        return response()->json(['message' => 'Supplement created successfully', 'supplement' => $supplement], 201);
    }

    public function update(Request $request, $id)
    {
        $supplement = Supplement::find($id);
        if (!$supplement) {
            return response()->json(['error' => 'Supplement not found'], 404);
        }

        $supplement->update($request->all());
        return response()->json(['message' => 'Supplement updated successfully', 'supplement' => $supplement]);
    }

    public function destroy($id)
    {
        $supplement = Supplement::find($id);
        if (!$supplement) {
            return response()->json(['error' => 'Supplement not found'], 404);
        }

        $supplement->delete();
        return response()->json(['message' => 'Supplement deleted successfully']);
    }
}
