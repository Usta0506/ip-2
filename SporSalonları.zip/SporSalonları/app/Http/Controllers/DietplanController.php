<?php


namespace App\Http\Controllers;

use App\Models\DietPlan;
use Illuminate\Http\Request;

class DietPlanController extends Controller
{
    public function index()
    {
        $dietPlans = DietPlan::all();
        return response()->json($dietPlans);
    }

    public function show($id)
    {
        $dietPlan = DietPlan::find($id);
        if (!$dietPlan) {
            return response()->json(['error' => 'Diet Plan not found'], 404);
        }
        return response()->json($dietPlan);
    }

    public function store(Request $request)
    {
        $request->validate([
            'CustomerID' => 'required|exists:customers,CustomerID',
            'TrainerID' => 'required|exists:trainers,TrainerID',
            'PlanDescription' => 'required|string',
            'StartDate' => 'required|date',
            'EndDate' => 'required|date',
        ]);

        $dietPlan = DietPlan::create($request->all());
        return response()->json(['message' => 'Diet Plan created successfully', 'dietPlan' => $dietPlan], 201);
    }

    public function update(Request $request, $id)
    {
        $dietPlan = DietPlan::find($id);
        if (!$dietPlan) {
            return response()->json(['error' => 'Diet Plan not found'], 404);
        }

        $dietPlan->update($request->all());
        return response()->json(['message' => 'Diet Plan updated successfully', 'dietPlan' => $dietPlan]);
    }

    public function destroy($id)
    {
        $dietPlan = DietPlan::find($id);
        if (!$dietPlan) {
            return response()->json(['error' => 'Diet Plan not found'], 404);
        }

        $dietPlan->delete();
        return response()->json(['message' => 'Diet Plan deleted successfully']);
    }
}
