<?php

namespace App\Http\Controllers;

use App\Models\ProgramExercise;
use Illuminate\Http\Request;

class ProgramExerciseController extends Controller
{
    public function index()
    {
        $programExercises = ProgramExercise::all();
        return response()->json($programExercises);
    }

    public function show($id)
    {
        $programExercise = ProgramExercise::find($id);
        if (!$programExercise) {
            return response()->json(['error' => 'Program Exercise not found'], 404);
        }
        return response()->json($programExercise);
    }

    public function store(Request $request)
    {
        $request->validate([
            'WorkoutPlanID' => 'required|exists:workout_plans,WorkoutPlanID',
            'ExerciseID' => 'required|exists:exercises,ExerciseID',
            'SetCount' => 'required|integer',
            'RepetitionCount' => 'required|integer',
        ]);

        $programExercise = ProgramExercise::create($request->all());
        return response()->json(['message' => 'Program Exercise created successfully', 'programExercise' => $programExercise], 201);
    }

    public function update(Request $request, $id)
    {
        $programExercise = ProgramExercise::find($id);
        if (!$programExercise) {
            return response()->json(['error' => 'Program Exercise not found'], 404);
        }

        $programExercise->update($request->all());
        return response()->json(['message' => 'Program Exercise updated successfully', 'programExercise' => $programExercise]);
    }

    public function destroy($id)
    {
        $programExercise = ProgramExercise::find($id);
        if (!$programExercise) {
            return response()->json(['error' => 'Program Exercise not found'], 404);
        }

        $programExercise->delete();
        return response()->json(['message' => 'Program Exercise deleted successfully']);
    }
}
