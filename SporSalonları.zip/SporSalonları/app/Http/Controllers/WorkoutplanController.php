<?php


namespace App\Http\Controllers;

use App\Models\WorkoutPlan;
use Illuminate\Http\Request;

class WorkoutplanController extends Controller
{
    public function index()
    {
        $workoutPlans = WorkoutPlan::all();
        return response()->json($workoutPlans);
    }

    public function show($id)
    {
        $workoutPlan = WorkoutPlan::find($id);
        if (!$workoutPlan) {
            return response()->json(['error' => 'Workout Plan not found'], 404);
        }
        return response()->json($workoutPlan);
    }

    public function store(Request $request)
    {
        $request->validate([
            'ProgramID' => 'required|exists:programs,ProgramID',
            'CustomerID' => 'required|exists:customers,CustomerID',
            'StartDate' => 'required|date',
            'EndDate' => 'required|date',
        ]);

        $workoutPlan = WorkoutPlan::create($request->all());
        return response()->json(['message' => 'Workout Plan created successfully', 'workoutPlan' => $workoutPlan], 201);
    }

    public function update(Request $request, $id)
    {
        $workoutPlan = WorkoutPlan::find($id);
        if (!$workoutPlan) {
            return response()->json(['error' => 'Workout Plan not found'], 404);
        }

        $workoutPlan->update($request->all());
        return response()->json(['message' => 'Workout Plan updated successfully', 'workoutPlan' => $workoutPlan]);
    }

    public function destroy($id)
    {
        $workoutPlan = WorkoutPlan::find($id);
        if (!$workoutPlan) {
            return response()->json(['error' => 'Workout Plan not found'], 404);
        }

        $workoutPlan->delete();
        return response()->json(['message' => 'Workout Plan deleted successfully']);
    }
}
