<?php


namespace App\Http\Controllers;

use App\Models\Program;
use Illuminate\Http\Request;

class ProgramController extends Controller
{
    public function index()
    {
        $programs = Program::all();
        return response()->json($programs);
    }

    public function show($id)
    {
        $program = Program::find($id);
        if (!$program) {
            return response()->json(['error' => 'Program not found'], 404);
        }
        return response()->json($program);
    }

    public function store(Request $request)
    {
        $request->validate([
            'Name' => 'required|string|max:50',
            'Description' => 'required|string',
        ]);

        $program = Program::create($request->all());
        return response()->json(['message' => 'Program created successfully', 'program' => $program], 201);
    }

    public function update(Request $request, $id)
    {
        $program = Program::find($id);
        if (!$program) {
            return response()->json(['error' => 'Program not found'], 404);
        }

        $program->update($request->all());
        return response()->json(['message' => 'Program updated successfully', 'program' => $program]);
    }

    public function destroy($id)
    {
        $program = Program::find($id);
        if (!$program) {
            return response()->json(['error' => 'Program not found'], 404);
        }

        $program->delete();
        return response()->json(['message' => 'Program deleted successfully']);
    }
}
