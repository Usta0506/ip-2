<?php


use App\Http\Controllers\ClassController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\MembershipController;
use App\Http\Controllers\TrainerController;
use App\Http\Controllers\GymController;
use App\Http\Controllers\ExerciseController;
use App\Http\Controllers\ProgramController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\ShiftController;
use App\Http\Controllers\ParticipationController;
use App\Http\Controllers\DietPlanController;
use App\Http\Controllers\SupplementController;
use App\Http\Controllers\LockerRoomController;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('home');
})->name('home');


Route::resource('customers', CustomerController::class);


Route::resource('memberships', MembershipController::class);


Route::resource('trainers', TrainerController::class);


Route::resource('gyms', GymController::class);


Route::resource('exercises', ExerciseController::class);


Route::resource('programs', ProgramController::class);


Route::resource('payments', PaymentController::class);


Route::resource('invoices', InvoiceController::class);


Route::resource('staff', StaffController::class);


Route::resource('shifts', ShiftController::class);


Route::resource('participations', ParticipationController::class);


Route::resource('diet-plans', DietPlanController::class);


Route::resource('supplements', SupplementController::class);


Route::resource('locker-rooms', LockerRoomController::class);


Route::resource('classes', ClassController::class);


